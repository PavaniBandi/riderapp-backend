package com.example.riderdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiderdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiderdemoApplication.class, args);
	}

}
