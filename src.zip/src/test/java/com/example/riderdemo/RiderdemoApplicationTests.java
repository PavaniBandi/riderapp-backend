package com.example.riderdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiderdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
